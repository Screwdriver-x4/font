/* To avoid CSS expressions while still supporting IE 7 and IE 6, use this script */
/* The script tag referencing this file must be placed before the ending body tag. */

/* Use conditional comments in order to target IE 7 and older:
	<!--[if lt IE 8]><!-->
	<script src="ie7/ie7.js"></script>
	<!--<![endif]-->
*/

(function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'Jump-26-Dump\'">' + entity + '</span>' + html;
	}
	var icons = {
		'icon-Jump-26-Dumpa': '&#x61;',
		'icon-Jump-26-Dumpb': '&#x62;',
		'icon-Jump-26-Dumpc': '&#x63;',
		'icon-Jump-26-Dumpd': '&#x64;',
		'icon-Jump-26-Dumpe': '&#x65;',
		'icon-Jump-26-Dumpf': '&#x66;',
		'icon-Jump-26-Dumpg': '&#x67;',
		'icon-Jump-26-Dumph': '&#x68;',
		'icon-Jump-26-Dumpi': '&#x69;',
		'icon-Jump-26-Dumpj': '&#x6a;',
		'icon-Jump-26-Dumpk': '&#x6b;',
		'icon-Jump-26-Dumpl': '&#x6c;',
		'icon-Jump-26-Dumpm': '&#x6d;',
		'icon-Jump-26-Dumpn': '&#x6e;',
		'icon-Jump-26-Dumpo': '&#x6f;',
		'icon-Jump-26-Dumpp': '&#x70;',
		'icon-Jump-26-Dumpq': '&#x71;',
		'icon-Jump-26-Dumpr': '&#x72;',
		'icon-Jump-26-Dumps': '&#x73;',
		'icon-Jump-26-Dumpt': '&#x74;',
		'icon-Jump-26-Dumpu': '&#x75;',
		'icon-Jump-26-Dumpv': '&#x76;',
		'icon-Jump-26-Dumpw': '&#x77;',
		'icon-Jump-26-Dumpx': '&#x78;',
		'icon-Jump-26-Dumpy': '&#x79;',
		'icon-Jump-26-Dumpz': '&#x7a;',
		'0': 0
		},
		els = document.getElementsByTagName('*'),
		i, c, el;
	for (i = 0; ; i += 1) {
		el = els[i];
		if(!el) {
			break;
		}
		c = el.className;
		c = c.match(/icon-Jump-26-Dump[^\s'"]+/);
		if (c && icons[c[0]]) {
			addIcon(el, icons[c[0]]);
		}
	}
}());
